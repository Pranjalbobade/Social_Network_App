from django.apps import AppConfig

class NotificationConfig(AppConfig):
    name = 'notification'
