from django.apps import AppConfig

class FriendConfig(AppConfig):
    name = 'friend'
